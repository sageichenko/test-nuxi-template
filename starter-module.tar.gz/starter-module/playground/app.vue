<template>
  <div>
    Nuxt module playground!
  </div>
</template>

<script setup>
</script>
